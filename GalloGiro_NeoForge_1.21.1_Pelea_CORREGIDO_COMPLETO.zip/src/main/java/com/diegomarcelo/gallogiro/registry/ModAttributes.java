package com.diegomarcelo.gallogiro.registry;

import com.diegomarcelo.gallogiro.GalloGiro;
import com.diegomarcelo.gallogiro.entity.GalloEntity;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;

@EventBusSubscriber(modid = GalloGiro.MOD_ID, bus = EventBusSubscriber.Bus.MOD)
public final class ModAttributes {
    private ModAttributes() {}

    @SubscribeEvent
    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.GALLO.get(), GalloEntity.createAttributes().build());
    }
}
