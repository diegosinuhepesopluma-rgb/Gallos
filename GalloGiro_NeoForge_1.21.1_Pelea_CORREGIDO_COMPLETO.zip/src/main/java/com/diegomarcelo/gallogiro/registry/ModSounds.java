package com.diegomarcelo.gallogiro.registry;

import com.diegomarcelo.gallogiro.GalloGiro;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(BuiltInRegistries.SOUND_EVENT, GalloGiro.MOD_ID);

    public static final DeferredHolder<SoundEvent, SoundEvent> KIKIRIKI = SOUNDS.register(
            "kikiriki",
            () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(GalloGiro.MOD_ID, "kikiriki"))
    );

    private ModSounds() {}
}
