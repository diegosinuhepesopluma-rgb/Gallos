package com.diegomarcelo.gallogiro.client;

import com.diegomarcelo.gallogiro.GalloGiro;
import com.diegomarcelo.gallogiro.entity.GalloEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class GalloModel extends GeoModel<GalloEntity> {
    private static final ResourceLocation MODEL = ResourceLocation.fromNamespaceAndPath(GalloGiro.MOD_ID, "gallo_giro");
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(GalloGiro.MOD_ID, "textures/entity/gallo_giro_color_bien.png");
    private static final ResourceLocation ANIMATIONS = ResourceLocation.fromNamespaceAndPath(GalloGiro.MOD_ID, "gallo_giro");

    @Override
    public ResourceLocation getModelResource(GalloEntity animatable) {
        return MODEL;
    }

    @Override
    public ResourceLocation getTextureResource(GalloEntity animatable) {
        return TEXTURE;
    }

    @Override
    public ResourceLocation getAnimationResource(GalloEntity animatable) {
        return ANIMATIONS;
    }
}
