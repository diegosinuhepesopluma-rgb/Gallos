GALLOGIRO - NEOFORGE 1.21.1

Este archivo es un proyecto completo preparado para subir a GitHub.

IMPORTANTE:
1. Descomprime este ZIP.
2. Sube EL CONTENIDO de esta carpeta al repositorio, no el ZIP dentro de otra carpeta.
3. La raiz del repositorio debe contener build.gradle, settings.gradle, gradle.properties y src/.
4. .github/workflows/build.yml compila automaticamente.
5. Al terminar, GitHub Actions mostrara el JAR en Artifacts con el nombre:
   GalloGiro-NeoForge-1.21.1-JAR
