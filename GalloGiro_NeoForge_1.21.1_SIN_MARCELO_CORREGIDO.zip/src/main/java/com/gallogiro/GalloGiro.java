package com.gallogiro;

import com.gallogiro.registry.ModEntities;
import com.gallogiro.registry.ModSounds;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;

@Mod(GalloGiro.MOD_ID)
public final class GalloGiro {
    public static final String MOD_ID = "gallogiro";

    public GalloGiro(IEventBus modBus) {
        ModEntities.ENTITY_TYPES.register(modBus);
        ModSounds.SOUNDS.register(modBus);
        modBus.addListener(this::commonSetup);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        // Reserved for future common setup.
    }
}
