package com.gallogiro.registry;

import com.gallogiro.GalloGiro;
import com.gallogiro.entity.GalloEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(Registries.ENTITY_TYPE, GalloGiro.MOD_ID);

    public static final DeferredHolder<EntityType<?>, EntityType<GalloEntity>> GALLO =
            ENTITY_TYPES.register("gallo_giro", registryName -> EntityType.Builder
                    .of(GalloEntity::new, MobCategory.CREATURE)
                    .sized(1.0F, 1.8F)
                    .clientTrackingRange(8)
                    .build(ResourceKey.create(Registries.ENTITY_TYPE, registryName)));

    private ModEntities() {}
}
