package com.gallogiro.gallogiro.client;

import com.gallogiro.gallogiro.entity.GalloEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class GalloRenderer extends GeoEntityRenderer<GalloEntity> {
    public GalloRenderer(EntityRendererProvider.Context context) {
        super(context, new GalloModel());
        this.shadowRadius = 0.45F;
    }
}
