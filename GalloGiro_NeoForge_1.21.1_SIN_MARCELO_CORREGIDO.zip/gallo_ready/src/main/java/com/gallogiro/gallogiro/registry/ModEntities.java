package com.gallogiro.gallogiro.registry;

import com.gallogiro.gallogiro.GalloGiro;
import com.gallogiro.gallogiro.entity.GalloEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
    public static final DeferredRegister.Entities ENTITY_TYPES =
            DeferredRegister.createEntities(GalloGiro.MOD_ID);

    public static final DeferredHolder<EntityType<?>, EntityType<GalloEntity>> GALLO =
            ENTITY_TYPES.registerEntityType(
                    "gallo_giro",
                    GalloEntity::new,
                    MobCategory.CREATURE,
                    builder -> builder
                            .sized(1.0F, 1.8F)
                            .clientTrackingRange(8)
            );

    private ModEntities() {}
}
