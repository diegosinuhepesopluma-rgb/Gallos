package com.diegomarcelo.gallogiro.registry;

import com.diegomarcelo.gallogiro.GalloGiro;
import com.diegomarcelo.gallogiro.entity.GalloEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(Registries.ENTITY_TYPE, GalloGiro.MOD_ID);

    private static <E extends Entity> ResourceKey<EntityType<E>> key(String name) {
        return ResourceKey.create(
                Registries.ENTITY_TYPE,
                ResourceLocation.fromNamespaceAndPath(GalloGiro.MOD_ID, name)
        );
    }

    public static final DeferredHolder<EntityType<?>, EntityType<GalloEntity>> GALLO =
            ENTITY_TYPES.register(
                    "gallo_giro",
                    () -> EntityType.Builder.of(GalloEntity::new, MobCategory.CREATURE)
                            .sized(1.0F, 1.8F)
                            .clientTrackingRange(8)
                            .build(key("gallo_giro"))
            );

    private ModEntities() {}
}
